<?php return array (
  'lunch' => 'App\\Http\\Livewire\\Lunch',
);